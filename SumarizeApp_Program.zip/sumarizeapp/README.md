# sumarizeApp

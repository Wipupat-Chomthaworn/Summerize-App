import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const search = () => {
  return (
    <View>
      <Text>search</Text>
    </View>
  )
}

export default search

const styles = StyleSheet.create({})
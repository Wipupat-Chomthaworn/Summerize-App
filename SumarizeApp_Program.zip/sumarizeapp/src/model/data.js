export default sumarize = [{
    "_id": {
        "$oid": "651bd208f4607e1caddf568e"
    },
    "name": "Cisco",
    "author": "ken",
    "tag": [
        {
            "_id": {
                "$oid": "651ad3fc6fe2407d7c08afb0"
            },
            "tagname": "Security"
        }
    ],
    "_class": "com.example.sumarizeservice.Pojo.Sumarize"
},
{
    "_id": {
        "$oid": "651bd2ea00b0e5440c205add"
    },
    "name": "Cisco2",
    "author": "hello",
    "tag": [
        {
            "_id": {
                "$oid": "651ad3fc6fe2407d7c08afb0"
            },
            "tagname": "Security"
        }
    ],
    "_class": "com.example.sumarizeservice.Pojo.Sumarize"
}]